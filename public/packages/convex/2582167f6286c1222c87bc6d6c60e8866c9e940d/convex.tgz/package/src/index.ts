export const version = "1.47.0+convex-in-prod.2582167f6286";
