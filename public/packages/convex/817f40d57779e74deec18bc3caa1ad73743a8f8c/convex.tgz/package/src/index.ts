export const version = "1.49.0+convex-in-prod.817f40d57779";
