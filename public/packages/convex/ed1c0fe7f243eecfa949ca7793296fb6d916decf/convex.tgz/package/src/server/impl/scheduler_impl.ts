import { convexToJson, Value } from "../../values/index.js";
import { version } from "../../index.js";
import {
  ValueSyscall,
  performAsyncSyscall,
  performAsyncValueSyscall,
} from "./syscall.js";
import { parseArgs } from "../../common/index.js";
import { SchedulableFunctionReference, Scheduler } from "../scheduler.js";
import { FunctionReference_future } from "../api.js";
import { Id } from "../../values/value.js";
import { validateArg } from "./validate.js";
import { getFunctionAddress } from "../components/paths.js";

// Mirrors the constraint on `Scheduler.runAfter` and `Scheduler.runAt`, which
// is module-local to `scheduler.ts`.
type SchedulableFunctionReferenceCompat =
  | SchedulableFunctionReference
  | FunctionReference_future<"mutation" | "action", "public" | "internal">;

export function setupMutationScheduler(): Scheduler {
  return {
    runAfter: async (
      delayMs: number,
      functionReference: SchedulableFunctionReferenceCompat,
      args?: Record<string, Value>,
    ) => {
      const syscallArgs = runAfterSyscallArgs(delayMs, functionReference, args);
      return await performAsyncValueSyscall(
        ValueSyscall.Schedule,
        [syscallArgs.ts, syscallArgs.args, version, syscallArgs.address],
        () => ({
          ...syscallArgs.address,
          ts: syscallArgs.ts,
          version,
          args: convexToJson(syscallArgs.args),
        }),
        (result) => result,
      );
    },
    runAt: async (
      ms_since_epoch_or_date: number | Date,
      functionReference: SchedulableFunctionReferenceCompat,
      args?: Record<string, Value>,
    ) => {
      const syscallArgs = runAtSyscallArgs(
        ms_since_epoch_or_date,
        functionReference,
        args,
      );
      return await performAsyncValueSyscall(
        ValueSyscall.Schedule,
        [syscallArgs.ts, syscallArgs.args, version, syscallArgs.address],
        () => ({
          ...syscallArgs.address,
          ts: syscallArgs.ts,
          version,
          args: convexToJson(syscallArgs.args),
        }),
        (result) => result,
      );
    },
    cancel: async (id: Id<"_scheduled_functions">) => {
      validateArg(id, 1, "cancel", "id");
      await performAsyncValueSyscall(
        ValueSyscall.CancelJob,
        [id],
        () => ({ id: convexToJson(id) }),
        () => undefined,
      );
    },
  };
}

export function setupActionScheduler(requestId: string): Scheduler {
  return {
    runAfter: async (
      delayMs: number,
      functionReference: SchedulableFunctionReferenceCompat,
      args?: Record<string, Value>,
    ) => {
      const syscallArgs = {
        requestId,
        ...runAfterSyscallArgs(delayMs, functionReference, args),
      };
      return await performAsyncSyscall("1.0/actions/schedule", {
        ...syscallArgs.address,
        requestId,
        ts: syscallArgs.ts,
        version,
        args: convexToJson(syscallArgs.args),
      });
    },
    runAt: async (
      ms_since_epoch_or_date: number | Date,
      functionReference: SchedulableFunctionReferenceCompat,
      args?: Record<string, Value>,
    ) => {
      const syscallArgs = {
        requestId,
        ...runAtSyscallArgs(ms_since_epoch_or_date, functionReference, args),
      };
      return await performAsyncSyscall("1.0/actions/schedule", {
        ...syscallArgs.address,
        requestId,
        ts: syscallArgs.ts,
        version,
        args: convexToJson(syscallArgs.args),
      });
    },
    cancel: async (id: Id<"_scheduled_functions">) => {
      validateArg(id, 1, "cancel", "id");
      const syscallArgs = {
        requestId,
        id: convexToJson(id),
      };
      return await performAsyncSyscall("1.0/actions/cancel_job", syscallArgs);
    },
  };
}

function runAfterSyscallArgs(
  delayMs: number,
  functionReference: SchedulableFunctionReferenceCompat,
  args?: Record<string, Value>,
) {
  if (typeof delayMs !== "number") {
    throw new Error("`delayMs` must be a number");
  }
  if (!isFinite(delayMs)) {
    throw new Error("`delayMs` must be a finite number");
  }
  if (delayMs < 0) {
    throw new Error("`delayMs` must be non-negative");
  }
  const functionArgs = parseArgs(args);
  const address = getFunctionAddress(functionReference);
  // Note the syscall expects a unix timestamp, measured in seconds.
  const ts = (Date.now() + delayMs) / 1000.0;
  return {
    address,
    ts,
    args: functionArgs,
    version,
  };
}

function runAtSyscallArgs(
  ms_since_epoch_or_date: number | Date,
  functionReference: SchedulableFunctionReferenceCompat,
  args?: Record<string, Value>,
) {
  let ts;
  if (ms_since_epoch_or_date instanceof Date) {
    ts = ms_since_epoch_or_date.valueOf() / 1000.0;
  } else if (typeof ms_since_epoch_or_date === "number") {
    // The timestamp the developer passes is in milliseconds, while the syscall
    // accepts seconds since the epoch.
    ts = ms_since_epoch_or_date / 1000;
  } else {
    throw new Error("The invoke time must a Date or a timestamp");
  }
  const address = getFunctionAddress(functionReference);
  const functionArgs = parseArgs(args);
  return {
    address,
    ts,
    args: functionArgs,
    version,
  };
}
