export const version = "1.47.0+convex-in-prod.694f7dd00e4f";
