export const version = "1.47.0+convex-in-prod.cb6849d8dce1";
