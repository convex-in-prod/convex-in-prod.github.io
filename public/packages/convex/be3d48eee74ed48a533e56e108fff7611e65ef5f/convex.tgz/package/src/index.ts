export const version = "1.47.0+convex-in-prod.be3d48eee74e";
