export const version = "1.47.0+convex-in-prod.018397d429f0";
