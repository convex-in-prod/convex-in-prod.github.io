export const version = "1.47.0+convex-in-prod.1e2892adaec9";
