export const version = "1.47.0+convex-in-prod.e3300a26c588";
