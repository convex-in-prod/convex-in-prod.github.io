export const version = "1.47.0+convex-in-prod.e439f7c7e2bb";
