export const version = "1.49.0+convex-in-prod.5f01b77b5f8b";
