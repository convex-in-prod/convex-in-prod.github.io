import { convexToJson, PropertyValidators } from "../../values/index.js";
import { version } from "../../index.js";
import {
  AnyFunctionReference,
  FunctionArgs,
  FunctionReference,
  FunctionReference_future,
  FunctionType,
} from "../api.js";
import { ValueSyscall, performAsyncValueSyscall } from "../impl/syscall.js";
import { DefaultFunctionArgs, FunctionVisibility } from "../registration.js";
import {
  AppDefinitionAnalysis,
  ComponentDefinitionAnalysis,
  ComponentDefinitionType,
  SerializedComponentArg,
} from "./definition.js";
import {
  extractReferencePath,
  getFunctionAddress,
  setReferencePath,
  toReferencePath,
} from "./paths.js";
import { functionName } from "../functionName.js";
import { isSimpleObject } from "../../common/index.js";
import type {
  Validator,
  VLiteral,
  VOptional,
  VString,
  VUnion,
} from "../../values/validators.js";
import type { Infer } from "../../values/validator.js";
import type { Value } from "../../values/value.js";
import { isValidator } from "../../values/validator.js";
import type { Expand } from "../../type_utils.js";
export { getFunctionAddress } from "./paths.js";

/**
 * A serializable reference to a Convex function.
 * Passing a this reference to another component allows that component to call this
 * function during the current function execution or at any later time.
 * Function handles are used like `api.folder.function` FunctionReferences,
 * e.g. `ctx.scheduler.runAfter(0, functionReference, args)`.
 *
 * A function reference is stable across code pushes but it's possible
 * the Convex function it refers to might no longer exist.
 *
 * This is a feature of components, which are in beta.
 * This API is unstable and may change in subsequent releases.
 */
export type FunctionHandle<
  Type extends FunctionType,
  Args extends DefaultFunctionArgs = any,
  ReturnType = any,
> = string & FunctionReference<Type, "internal", Args, ReturnType>;

/**
 * A {@link FunctionHandle} with the type semantics of {@link FunctionReference_future}.
 *
 * @public
 */
export type FunctionHandle_future<
  Type extends FunctionType,
  Args extends DefaultFunctionArgs = any,
  ReturnType = any,
> = string & FunctionReference_future<Type, "internal", Args, ReturnType>;

/**
 * Create a serializable reference to a Convex function.
 * Passing a this reference to another component allows that component to call this
 * function during the current function execution or at any later time.
 * Function handles are used like `api.folder.function` FunctionReferences,
 * e.g. `ctx.scheduler.runAfter(0, functionReference, args)`.
 *
 * A function reference is stable across code pushes but it's possible
 * the Convex function it refers to might no longer exist.
 *
 * This is a feature of components, which are in beta.
 * This API is unstable and may change in subsequent releases.
 */
export async function createFunctionHandle<
  Type extends FunctionType,
  Args extends DefaultFunctionArgs,
  ReturnType,
>(
  functionReference:
    | FunctionReference<Type, "public" | "internal", Args, ReturnType>
    | FunctionReference_future<Type, "public" | "internal", Args, ReturnType>,
): Promise<FunctionHandle<Type, Args, ReturnType>> {
  const address = getFunctionAddress(functionReference);
  return await performAsyncValueSyscall(
    ValueSyscall.FunctionHandle,
    [version, address],
    () => ({ ...address, version }),
    (result) => result,
  );
}

interface ComponentExports {
  [key: string]: FunctionReference<any, any, any, any> | ComponentExports;
}

/**
 * An object of this type should be the default export of a
 * convex.config.ts file in a component definition directory.
 *
 * This is a feature of components, which are in beta.
 * This API is unstable and may change in subsequent releases.
 */
export type ComponentDefinition<
  Exports extends ComponentExports = any,
  Env extends EnvDefinition = {},
> = {
  /**
   * TODO: replace the overload below with this when releasing args.
   *
   * @internal
   */
  use<Definition extends ComponentDefinition<any, any>>(
    definition: Definition,
    ...args: UseArgsInternal<Definition>
  ): InstalledComponent<Definition>;

  /**
   * Install a component with the given definition in this component definition.
   *
   * Takes a component definition and an optional name.
   *
   * For editor tooling this method expects a {@link ComponentDefinition}
   * but at runtime the object that is imported will be a {@link ImportedComponentDefinition}
   */
  use<Definition extends ComponentDefinition<any, any>>(
    definition: Definition,
    ...args: UseArgs<Definition>
  ): InstalledComponent<Definition>;

  /**
   * Internal type-only property tracking exports provided.
   *
   * @deprecated This is a type-only property, don't use it.
   */
  __exports: Exports;

  /**
   * References to this component's declared env vars. Pass one of these in
   * `app.use(child, { env: { ... } })` to bind a child's env var by
   * reference to this component's env var.
   */
  env: EnvRefFromDefinition<Env>;

  /**
   * Internal type-only property tracking env definition.
   *
   * @deprecated This is a type-only property, don't use it.
   */
  __env: Env;
};

/**
 * TODO: replace ComponentDefinition with this when releasing args.
 *
 * @internal
 */
export type ComponentDefinitionInternal<
  Exports extends ComponentExports = any,
  Env extends EnvDefinition = {},
  Args extends ComponentArgs = {},
> = ComponentDefinition<Exports, Env> & {
  /**
   * References to this component's own arguments, as declared by the `args`
   * validator of its init function. Pass one of these in
   * `component.use(child, { args: { ... } })` to forward an argument to a
   * child component.
   */
  args: ComponentArgRefs<Args>;

  /**
   * Internal type-only property tracking the init mutation's arguments.
   *
   * @deprecated This is a type-only property, don't use it.
   */
  __args: Args;
};

type ComponentDefinitionExports<T extends ComponentDefinition<any, any>> =
  T["__exports"];

type ComponentDefinitionEnv<T extends ComponentDefinition<any, any>> =
  T["__env"];

type ComponentDefinitionArgs<T extends ComponentDefinition<any, any>> =
  T extends { __args?: infer Args extends ComponentArgs } ? Args : {};

/**
 * The names in an {@link EnvDefinition} whose validators are required (not
 * wrapped in `v.optional(...)`).
 */
type RequiredEnvKeys<E extends EnvDefinition> = {
  [K in keyof E]: E[K] extends Validator<any, "optional", any> ? never : K;
}[keyof E];

/**
 * Options for installing a component via `app.use()` or `component.use()`.
 *
 * If the component declares any required env vars, the `env` property is
 * required. Otherwise it is optional, so that a component with no env vars (or
 * only optional ones) can be installed without passing `env`.
 */
type UseOptions<Definition extends ComponentDefinition<any, any>> =
  RequiredEnvKeys<ComponentDefinitionEnv<Definition>> extends never
    ? {
        name?: string;
        httpPrefix?: string;
        env?: UseOptionsEnv<ComponentDefinitionEnv<Definition>>;
      }
    : {
        name?: string;
        httpPrefix?: string;
        env: UseOptionsEnv<ComponentDefinitionEnv<Definition>>;
      };

/**
 * The arguments to `use()` after the component definition.
 *
 * When the component declares required env vars the `options` argument is
 * mandatory (so it can't be dropped to skip the required `env`); otherwise it
 * is optional.
 */
type UseArgs<Definition extends ComponentDefinition<any, any>> =
  RequiredEnvKeys<ComponentDefinitionEnv<Definition>> extends never
    ? [options?: UseOptions<Definition>]
    : [options: UseOptions<Definition>];

/**
 * {@link UseOptions} plus `args` for the component's init, which is required
 * exactly when the init has required arguments.
 *
 * TODO: replace UseOptions with this when releasing args.
 *
 * @internal
 */
type UseOptionsInternal<Definition extends ComponentDefinition<any, any>> =
  Expand<
    {
      name?: string;
      httpPrefix?: string;
    } & ([RequiredEnvKeys<ComponentDefinitionEnv<Definition>>] extends [never]
      ? { env?: UseOptionsEnv<ComponentDefinitionEnv<Definition>> }
      : { env: UseOptionsEnv<ComponentDefinitionEnv<Definition>> }) &
      ({} extends UseOptionsArgs<ComponentDefinitionArgs<Definition>>
        ? { args?: UseOptionsArgs<ComponentDefinitionArgs<Definition>> }
        : { args: UseOptionsArgs<ComponentDefinitionArgs<Definition>> })
  >;

/**
 * {@link UseArgs} for a component that may declare an init: `options` is also
 * mandatory when the init has required arguments.
 *
 * TODO: replace UseArgs with this when releasing args.
 *
 * @internal
 */
type UseArgsInternal<Definition extends ComponentDefinition<any, any>> =
  {} extends UseOptionsInternal<Definition>
    ? [options?: UseOptionsInternal<Definition>]
    : [options: UseOptionsInternal<Definition>];

/**
 * The values a parent may pass for a component's arguments.
 *
 * @internal
 */
type UseOptionsArgs<Args extends ComponentArgs> = [keyof Args] extends [never]
  ? Record<string, never>
  : Expand<{ [K in keyof Args]: ComponentArgInput<Args[K]> }>;

/**
 * The arguments of a component's init: what its `args` validator accepts, or
 * `Record<string, unknown>` for an init without one, which accepts anything.
 *
 * TODO: make this public when releasing args.
 *
 * @internal
 */
export type ComponentArgs = DefaultFunctionArgs;

/**
 * The value a parent may pass for a given component argument.
 *
 * If the type of the argument is a {@link FunctionHandle_future}, a {@link FunctionReference} may be passed in because it is not possible to create function handles when defining a component.
 *
 * The parent may also forward its own component arguments to a child component.
 *
 * TODO: make this public when releasing args.
 *
 * @internal
 */
export type ComponentArgInput<T> =
  | ComponentArgRef<T>
  | (T extends FunctionHandle_future<infer Type, infer Args, infer Returns>
      ? FunctionReference_future<Type, FunctionVisibility, Args, Returns>
      : T extends (infer Element extends Value)[]
        ? ComponentArgInput<Element>[]
        : T extends { [key: string]: Value | undefined }
          ?
              | { [K in keyof T]: ComponentArgInput<T[K]> }
              // The backend resolves an installed component to an object of
              // handles to its exports.
              | InstalledComponent<
                  ComponentDefinition<ComponentExportsForArg<T>, any>
                >
          : T);

/**
 * What a component must export to be passed to an argument of type `T`.
 *
 * For example, to pass a component as `{ fns: { ping: FunctionHandle<"mutation"> } }`,
 * it must export a mutation at `fns.ping`.
 */
type ComponentExportsForArg<T> =
  T extends FunctionHandle_future<infer Type, infer Args, infer Returns>
    ? FunctionReference_future<Type, FunctionVisibility, Args, Returns>
    : T extends { [key: string]: Value | undefined }
      ? { [K in keyof T]: ComponentExportsForArg<T[K]> }
      : never;

/**
 * A reference to one of a component's own arguments, produced by
 * `component.args.<NAME>`. Pass this in `component.use(child, { args: ... })`
 * to forward the argument to a child component.
 *
 * TODO: make this public when releasing args.
 *
 * @internal
 */
export type ComponentArgRef<T = any> = {
  __componentArgRef: string;

  __argType: T;
};

/**
 * Compute the typed `args` namespace from an init mutation's arguments.
 *
 * TODO: make this public when releasing args.
 *
 * @internal
 */
export type ComponentArgRefs<Args extends ComponentArgs> = {
  [K in keyof Args & string]-?: ComponentArgRef<Args[K]>;
};

type UseOptionsEnv<E extends EnvDefinition> = Expand<
  {
    [K in keyof E as E[K] extends Validator<any, "optional", any> ? never : K]:
      | Infer<E[K]>
      | EnvRef;
  } & {
    [K in keyof E as E[K] extends Validator<any, "optional", any>
      ? K
      : never]?: Infer<E[K]> | EnvRef | undefined;
  }
>;

/**
 * A string-like validator: `v.string()`, a string `v.literal("...")`, or a
 * `v.union(...)` of those (recursively). Component env vars are serialized
 * as strings on the wire, so only string-typed validators are allowed.
 *
 * @public
 */
export type StringLikeValidator =
  | VString<string, "required">
  | VLiteral<string, "required">
  | VUnion<string, Validator<any, "required", any>[], "required">;

/**
 * A definition of environment variables for the app.
 *
 * Maps environment variable names to string-like validators. Use
 * `v.string()` for a plain string, `v.literal("a")` for an enum value, or
 * `v.union(v.literal("a"), v.literal("b"))` for an enum. Wrap in
 * `v.optional(...)` for optional vars.
 *
 * @example
 * ```typescript
 * import { defineApp } from "convex/server";
 * import { v } from "convex/values";
 *
 * const app = defineApp({
 *   env: {
 *     OPENAI_API_KEY: v.string(),
 *     DEBUG_MODE: v.optional(v.string()),
 *   },
 * });
 * ```
 *
 * @public
 */
export type EnvDefinition = Record<
  string,
  StringLikeValidator | VOptional<StringLikeValidator>
>;

/**
 * Compute the typed environment object from an {@link EnvDefinition}.
 *
 * Required entries get the validator's inferred string type; optional
 * entries are `T | undefined`.
 *
 * @public
 */
export type EnvFromDefinition<E extends EnvDefinition> = Expand<
  {
    [K in keyof E as E[K] extends Validator<any, "optional", any>
      ? never
      : K]: Infer<E[K]>;
  } & {
    [K in keyof E as E[K] extends Validator<any, "optional", any>
      ? K
      : never]?: Infer<E[K]> | undefined;
  }
>;

/**
 * A reference to a parent-declared env var, produced by `app.env.<NAME>` or
 * `component.env.<NAME>`. Pass this in `use(child, { env: { ... } })` to
 * bind a child's declared env var to the parent's env var by reference
 * instead of snapshotting its current value.
 *
 * @public
 */
export type EnvRef<K extends string = string> = { __envVarRef: K };

/**
 * Compute the typed `env` namespace object from an {@link EnvDefinition}.
 * Each declared name maps to an {@link EnvRef} for that name.
 *
 * @public
 */
export type EnvRefFromDefinition<E extends EnvDefinition> = {
  [K in keyof E & string]: EnvRef<K>;
};

/**
 * Extract the typed environment from an {@link AppDefinition}.
 *
 * @public
 */
export type EnvFromAppDefinition<A> =
  A extends AppDefinition<infer E>
    ? EnvFromDefinition<E>
    : Record<string, never>;

/**
 * An object of this type should be the default export of a
 * convex.config.ts file in a component-aware convex directory.
 *
 * This is a feature of components, which are in beta.
 * This API is unstable and may change in subsequent releases.
 */
export type AppDefinition<Env extends EnvDefinition = EnvDefinition> = {
  /**
   * TODO: replace the overload below with this when releasing args.
   *
   * @internal
   */
  use<Definition extends ComponentDefinition<any, any>>(
    definition: Definition,
    ...args: UseArgsInternal<Definition>
  ): InstalledComponent<Definition>;

  /**
   * Install a component with the given definition in this component definition.
   *
   * Takes a component definition and an optional name.
   *
   * For editor tooling this method expects a {@link ComponentDefinition}
   * but at runtime the object that is imported will be a {@link ImportedComponentDefinition}
   */
  use<Definition extends ComponentDefinition<any, any>>(
    definition: Definition,
    ...args: UseArgs<Definition>
  ): InstalledComponent<Definition>;

  /**
   * References to this app's declared env vars. Pass one of these in
   * `app.use(child, { env: { ... } })` to bind a child's env var by
   * reference to this app's env var.
   */
  env: EnvRefFromDefinition<Env>;

  /**
   * Internal type-only property tracking env definition.
   *
   * @deprecated This is a type-only property, don't use it.
   */
  __env: Env;
};

interface ExportTree {
  // Tree with serialized `Reference`s as leaves.
  [key: string]: string | ExportTree;
}

type CommonDefinitionData = {
  _isRoot: boolean;
  _childComponents: ChildComponent[];
  _exportTree: ExportTree;
};

type ChildComponent = [
  name: string,
  definition: ImportedComponentDefinition,
  env: Record<string, any> | null,
  httpPrefix: string | undefined,
  args: Record<string, any> | null,
];

type ComponentDefinitionData = CommonDefinitionData & {
  _env: PropertyValidators;
  _name: string;
  _init?: string;
  _onInitCallbacks: Record<string, (argsStr: string) => string>;
};
type AppDefinitionData = CommonDefinitionData & {
  _httpPrefix?: string;
  _env?: EnvDefinition;
};

/**
 * Used to refer to an already-installed component.
 */
class InstalledComponent<Definition extends ComponentDefinition<any, any>> {
  /**
   * @internal
   */
  _definition: Definition;

  /**
   * @internal
   */
  _name: string;

  constructor(definition: Definition, name: string) {
    this._definition = definition;
    this._name = name;
    setReferencePath(this, `_reference/childComponent/${name}`);
  }

  get exports(): ComponentDefinitionExports<Definition> {
    return createExports(this._name, []);
  }
}

function createExports(name: string, pathParts: string[]): any {
  const handler: ProxyHandler<any> = {
    get(_, prop: string | symbol) {
      if (typeof prop === "string") {
        const newParts = [...pathParts, prop];
        return createExports(name, newParts);
      } else if (prop === toReferencePath) {
        let reference = `_reference/childComponent/${name}`;
        for (const part of pathParts) {
          reference += `/${part}`;
        }
        return reference;
      } else {
        return undefined;
      }
    },
  };
  return new Proxy({}, handler);
}

function createEnvRefs(
  ownerLabel: string,
  declared: Record<string, any> | undefined,
): any {
  const handler: ProxyHandler<any> = {
    get(_, prop: string | symbol) {
      if (typeof prop !== "string") {
        return undefined;
      }
      if (!declared || !Object.prototype.hasOwnProperty.call(declared, prop)) {
        throw new Error(
          `Env var "${prop}" is not declared on ${ownerLabel}. Add it to the \`env\` option of ${ownerLabel === "this app" ? "defineApp" : "defineComponent"}.`,
        );
      }
      return { __envVarRef: prop };
    },
  };
  return new Proxy({}, handler);
}

function createComponentArgRefs(): any {
  const handler: ProxyHandler<any> = {
    get(_, prop: string | symbol) {
      if (typeof prop !== "string") {
        return undefined;
      }
      return { __componentArgRef: prop };
    },
  };
  return new Proxy({}, handler);
}

function isArgRef(value: unknown): value is ComponentArgRef {
  return (
    typeof value === "object" &&
    value !== null &&
    typeof (value as ComponentArgRef).__componentArgRef === "string"
  );
}

function isEnvRef(value: unknown): value is EnvRef {
  return (
    typeof value === "object" &&
    value !== null &&
    typeof (value as EnvRef).__envVarRef === "string"
  );
}

function use<Definition extends ComponentDefinition<any, any>>(
  this: CommonDefinitionData,
  definition: Definition,
  options?: {
    name?: string;
    httpPrefix?: string;
    env?: Record<string, any>;
    args?: Record<string, any>;
  },
): InstalledComponent<Definition> {
  // At runtime an imported component will have this shape.
  const importedComponentDefinition =
    definition as unknown as ImportedComponentDefinition;
  if (typeof importedComponentDefinition.componentDefinitionPath !== "string") {
    throw new Error(
      "Component definition does not have the required componentDefinitionPath property. This code only works in Convex runtime.",
    );
  }
  const name =
    options?.name ??
    // added recently
    importedComponentDefinition.defaultName ??
    // can be removed once backend is out
    importedComponentDefinition.componentDefinitionPath.split("/").pop()!;

  if (typeof name !== "string") {
    throw new Error(
      `Component name must be a string. Received: ${typeof name}`,
    );
  }
  if (name.length === 0) {
    // "" is used internally as the name for the root component, so
    // users shouldn't try to define child components with an empty name.
    throw new Error("Component name cannot be empty.");
  }

  const httpPrefix = options?.httpPrefix;
  if (httpPrefix !== undefined) {
    if (!httpPrefix.startsWith("/")) {
      throw new Error(
        `httpPrefix must start with "/". Received: "${httpPrefix}"`,
      );
    }
  }

  const envValues: Record<string, any> = {};
  if (options?.env) {
    for (const [key, value] of Object.entries(options.env)) {
      if (value !== undefined) {
        envValues[key] = value;
      }
    }
  }

  const argValues: Record<string, any> = {};
  if (options?.args) {
    for (const [key, value] of Object.entries(options.args)) {
      if (value !== undefined) {
        argValues[key] = value;
      }
    }
  }

  this._childComponents.push([
    name,
    importedComponentDefinition,
    envValues,
    httpPrefix,
    argValues,
  ]);
  return new InstalledComponent(definition, name);
}

/**
 * The runtime type of a ComponentDefinition. TypeScript will claim
 * the default export of a module like "cool-component/convex.config.js"
 * is a `@link ComponentDefinition}, but during component definition evaluation
 * this is its type instead.
 *
 * This is a feature of components, which are in beta.
 * This API is unstable and may change in subsequent releases.
 */
export type ImportedComponentDefinition = {
  componentDefinitionPath: string;
  defaultName: string;
};

function exportAppForAnalysis(
  this: ComponentDefinition<any, any> & AppDefinitionData,
): AppDefinitionAnalysis {
  const definitionType = { type: "app" as const };
  const childComponents = serializeChildComponents(this._childComponents);
  const httpMounts = buildHttpMounts(this._childComponents);
  const envVars = this._env
    ? Object.entries(this._env).map(
        ([name, validator]) =>
          [
            name,
            {
              type: "value" as const,
              value: JSON.stringify(validator.json),
              ...(validator.isOptional === "optional"
                ? { optional: true }
                : {}),
            },
          ] as [string, { type: "value"; value: string; optional?: boolean }],
      )
    : undefined;
  return {
    definitionType,
    ...(this._httpPrefix !== undefined
      ? { httpPrefix: normalizeHttpPrefix(this._httpPrefix) }
      : {}),
    childComponents: childComponents as any,
    httpMounts,
    exports: serializeExportTree(this._exportTree),
    ...(envVars !== undefined ? { envVars } : {}),
  };
}

function serializeExportTree(tree: ExportTree): any {
  const branch: any[] = [];
  for (const [key, child] of Object.entries(tree)) {
    let node;
    if (typeof child === "string") {
      node = { type: "leaf", leaf: child };
    } else {
      node = serializeExportTree(child);
    }
    branch.push([key, node]);
  }
  return { type: "branch", branch };
}

function normalizeHttpPrefix(prefix: string): string {
  // Ensure the prefix ends with "/" as required by HttpMountPath in Rust.
  return prefix.endsWith("/") ? prefix : prefix + "/";
}

function buildHttpMounts(
  childComponents: ChildComponent[],
): Record<string, string> {
  const httpMounts: Record<string, string> = {};
  for (const [name, , , httpPrefix] of childComponents) {
    if (httpPrefix !== undefined) {
      const normalized = normalizeHttpPrefix(httpPrefix);
      httpMounts[normalized] = `_reference/childComponent/${name}`;
    }
  }
  return httpMounts;
}

type SerializedEnvArg =
  | { type: "value"; value: string }
  | { type: "envVar"; name: string };

function serializeChildComponents(childComponents: ChildComponent[]): {
  name: string;
  path: string;
  env: [string, SerializedEnvArg][] | null;
  args: [string, SerializedComponentArg][];
}[] {
  return childComponents.map(([name, definition, p, , a]) => {
    // Note: httpPrefix (4th element) is used separately in buildHttpMounts()
    let env: [string, SerializedEnvArg][] | null = null;
    if (p !== null) {
      env = [];
      for (const [name, value] of Object.entries(p)) {
        if (value === undefined) {
          continue;
        }
        if (isEnvRef(value)) {
          env.push([name, { type: "envVar", name: value.__envVarRef }]);
        } else if (typeof value === "string") {
          env.push([name, { type: "value", value }]);
        } else {
          throw new Error(
            `Env var "${name}" must be a string or an env var reference. ` +
              `Received: ${typeof value}`,
          );
        }
      }
    }
    // args must always be a list. This is needed for compatibility for older backends before the legacy args validator code path was removed
    const args: [string, SerializedComponentArg][] = [];
    for (const [name, value] of Object.entries(a ?? {})) {
      if (value === undefined) {
        continue;
      }
      args.push([name, serializeComponentArg(name, value)]);
    }
    // we know that components carry this extra information
    const path = definition.componentDefinitionPath;
    if (!path)
      throw new Error(
        "no .componentPath for component definition " +
          JSON.stringify(definition, null, 2),
      );

    return {
      name: name!,
      path: path!,
      env,
      args,
    };
  });
}

/**
 * Serialize one argument passed in `use(component, { args })`.
 */
function serializeComponentArg(
  path: string,
  value: any,
): SerializedComponentArg {
  if (isEnvRef(value)) {
    throw new Error(
      `Component argument "${path}" can't be an environment variable. ` +
        `Pass it with the \`env\` option instead.`,
    );
  }
  // `component.args.limit`, from the parent's own `defineComponent(...)`
  if (isArgRef(value)) {
    return { type: "parentArgument", name: value.__componentArgRef };
  }
  if (isFunctionReferenceObject(value)) {
    const address = getFunctionAddress(value);
    // `internal.module.func`
    if (address.name !== undefined) {
      return {
        type: "reference",
        reference: `_reference/function/${address.name}`,
      };
    }
    // `components.sibling`, `components.sibling.module.func`, or the value
    // returned by `use()`
    if (address.reference !== undefined) {
      return { type: "reference", reference: address.reference };
    }
    throw new Error(`Component argument "${path}" isn't a valid argument.`);
  }
  // Arrays and objects containing any of the above; ones that don't are
  // serialized as plain values below.
  if (Array.isArray(value)) {
    const elements = value.map((element, i) =>
      serializeComponentArg(`${path}[${i}]`, element),
    );
    if (elements.some((element) => element.type !== "value")) {
      return { type: "array", elements };
    }
  } else if (
    typeof value === "object" &&
    value !== null &&
    isSimpleObject(value)
  ) {
    const fields: [string, SerializedComponentArg][] = Object.entries(value)
      .filter(([, field]) => field !== undefined)
      .map(([key, field]) => [
        key,
        serializeComponentArg(`${path}.${key}`, field),
      ]);
    if (fields.some(([, field]) => field.type !== "value")) {
      return { type: "object", fields };
    }
  }
  try {
    return { type: "value", value: JSON.stringify(convexToJson(value)) };
  } catch (e: any) {
    throw new Error(
      `Component argument "${path}" isn't a valid argument: ${e.message}. `,
    );
  }
}

/**
 * Whether `value` is a FunctionReference in object form (returns false for a FunctionHandle)
 */
function isFunctionReferenceObject(value: any): boolean {
  if (typeof value !== "object" || value === null) {
    return false;
  }
  return (
    value[functionName] !== undefined || extractReferencePath(value) !== null
  );
}

function exportComponentForAnalysis(
  this: ComponentDefinition<any, any> & ComponentDefinitionData,
): ComponentDefinitionAnalysis {
  const envVars = Object.entries(this._env).map(
    ([name, validator]) =>
      [
        name,
        {
          type: "value" as const,
          value: JSON.stringify((validator as any).json),
          ...((validator as any).isOptional === "optional"
            ? { optional: true }
            : {}),
        },
      ] as [string, { type: "value"; value: string; optional?: boolean }],
  );
  const definitionType: ComponentDefinitionType = {
    type: "childComponent" as const,
    name: this._name,
    args: [],
  };
  const childComponents = serializeChildComponents(this._childComponents);
  const httpMounts = buildHttpMounts(this._childComponents);
  return {
    name: this._name,
    definitionType,
    childComponents: childComponents as any,
    httpMounts,
    exports: serializeExportTree(this._exportTree),
    ...(envVars.length > 0 ? { envVars } : {}),
    ...(this._init !== undefined ? { init: this._init } : {}),
  };
}

// This is what is actually contained in a ComponentDefinition.
type RuntimeComponentDefinition = Omit<
  ComponentDefinitionInternal<any, any, any>,
  "__exports" | "__env" | "__args"
> &
  ComponentDefinitionData & {
    export: () => ComponentDefinitionAnalysis;
  };
type RuntimeAppDefinition = Omit<AppDefinition<any>, "__env"> &
  AppDefinitionData & {
    export: () => AppDefinitionAnalysis;
  };

/**
 * Define a component, a piece of a Convex deployment with namespaced resources.
 *
 * Optionally define typed environment variables that will be available via
 * the `env` export from `_generated/server` in all Convex functions within
 * this component. Values are passed by the parent via
 * `app.use(component, { env: { ... } })`.
 *
 * @param name Name must be alphanumeric plus underscores. Typically these are
 * lowercase with underscores like `"onboarding_flow_tracker"`.
 *
 * This is a feature of components, which are in beta.
 * This API is unstable and may change in subsequent releases.
 */
export function defineComponent<
  Exports extends ComponentExports = any,
  const Env extends EnvDefinition = {},
>(
  name: string,
  options?: {
    env?: Env;
  },
): ComponentDefinition<Exports, Env>;
/**
 * TODO: make this overload public when releasing args.
 *
 * @internal
 */
export function defineComponent<
  Exports extends ComponentExports = any,
  const Env extends EnvDefinition = {},
  Init extends FunctionReference<"mutation", "internal"> = FunctionReference<
    "mutation",
    "internal",
    {}
  >,
>(
  name: string,
  options: {
    env?: Env;
    init: Init;
  },
): ComponentDefinitionInternal<Exports, Env, FunctionArgs<Init>>;
export function defineComponent(
  name: string,
  options?: {
    env?: EnvDefinition;
    init?: FunctionReference<"mutation", "internal">;
  },
): ComponentDefinitionInternal<any, any, any> {
  const envValidators: PropertyValidators = {};
  if (options?.env) {
    for (const [key, decl] of Object.entries(options.env)) {
      if (decl !== null && decl !== undefined && isValidator(decl)) {
        envValidators[key] = decl as any;
      } else {
        throw new Error(
          `Environment variable "${key}" must be defined with a validator (e.g. v.string()).`,
        );
      }
    }
  }

  let init: string | undefined;
  if (options?.init !== undefined) {
    const address = getFunctionAddress(options.init);
    if (address.name === undefined) {
      throw new Error(
        `The \`init\` option of component "${name}" must be a function in ` +
          `this component, e.g. \`internal.init.myInit\`.`,
      );
    }
    init = address.name;
  }

  const ret: RuntimeComponentDefinition = {
    _isRoot: false,
    _name: name,
    _env: envValidators,
    _childComponents: [],
    _exportTree: {},
    _onInitCallbacks: {},
    ...(init !== undefined ? { _init: init } : {}),

    env: createEnvRefs(`component "${name}"`, options?.env),
    args: createComponentArgRefs(),

    export: exportComponentForAnalysis,
    use,

    ...({} as { __exports: any; __env: any; __args: any }),
  };
  return ret as any;
}

/**
 * Attach components, reuseable pieces of a Convex deployment, to this Convex app.
 *
 * Optionally define typed environment variables that will be available via
 * the `env` export from `_generated/server` in all Convex functions.
 *
 * @example
 * ```typescript
 * import { defineApp } from "convex/server";
 * import { v } from "convex/values";
 *
 * const app = defineApp({
 *   env: {
 *     OPENAI_API_KEY: v.string(),
 *     DEBUG_MODE: v.optional(v.string()),
 *   },
 * });
 * export default app;
 * ```
 *
 * This is a feature of components, which are in beta.
 * This API is unstable and may change in subsequent releases.
 */
export function defineApp<Env extends EnvDefinition = EnvDefinition>(options?: {
  httpPrefix?: string;
  env?: Env;
}): AppDefinition<Env> {
  const httpPrefix = options?.httpPrefix;
  if (httpPrefix !== undefined && !httpPrefix.startsWith("/")) {
    throw new Error(
      `httpPrefix must start with "/". Received: "${httpPrefix}"`,
    );
  }
  const env = options?.env;
  if (env !== undefined) {
    for (const [name, validator] of Object.entries(env)) {
      if (!isValidator(validator)) {
        throw new Error(
          `Environment variable "${name}" must be defined with a validator (e.g. v.string()).`,
        );
      }
    }
  }
  const ret: RuntimeAppDefinition = {
    _isRoot: true,
    _childComponents: [],
    _exportTree: {},
    ...(httpPrefix !== undefined ? { _httpPrefix: httpPrefix } : {}),
    ...(env !== undefined ? { _env: env } : {}),

    env: createEnvRefs("this app", env),

    export: exportAppForAnalysis,
    use,
  };
  return ret as unknown as AppDefinition<Env>;
}

type AnyInterfaceType = {
  [key: string]: AnyInterfaceType;
} & AnyFunctionReference;
export type AnyComponentReference = Record<string, AnyInterfaceType>;

export type AnyChildComponents = Record<string, AnyComponentReference>;

/**
 * @internal
 */
export function currentSystemUdfInComponent(
  componentId: string,
): AnyComponentReference {
  return {
    [toReferencePath]: `_reference/currentSystemUdfInComponent/${componentId}`,
  };
}

function createChildComponents(
  root: string,
  pathParts: string[],
): AnyChildComponents {
  const handler: ProxyHandler<object> = {
    get(_, prop: string | symbol) {
      if (typeof prop === "string") {
        const newParts = [...pathParts, prop];
        return createChildComponents(root, newParts);
      } else if (prop === toReferencePath) {
        if (pathParts.length < 1) {
          const found = [root, ...pathParts].join(".");
          throw new Error(
            `API path is expected to be of the form \`${root}.childComponent.functionName\`. Found: \`${found}\``,
          );
        }
        return `_reference/childComponent/` + pathParts.join("/");
      } else {
        return undefined;
      }
    },
  };
  return new Proxy({}, handler);
}

export const componentsGeneric = () => createChildComponents("components", []);

export type AnyComponents = AnyChildComponents;
