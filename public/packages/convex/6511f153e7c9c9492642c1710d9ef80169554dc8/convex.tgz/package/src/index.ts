export const version = "1.47.0+convex-in-prod.6511f153e7c9";
